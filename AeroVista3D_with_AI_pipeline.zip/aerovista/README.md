# AeroVista 3D

Professional light-themed single-pass drone reconstruction workspace.

## Stack
- Frontend: React + TypeScript + Vite + Three.js
- Backend: Python + FastAPI
- Processing scaffold: OpenCV, NumPy, Open3D-ready architecture
- API: REST + WebSocket-ready job architecture

## Run backend

```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

## Run frontend

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

## Current behavior

The Upload Flight workflow uploads a video to FastAPI, extracts metadata, creates a processing job, and runs a lightweight frame-analysis scaffold. The UI polls the job and displays progress.

The reconstruction stages are intentionally modular. Replace the scaffold functions in `backend/pipeline/` with the final SfM/photogrammetry implementation after the frontend/API contract is validated.
