from pathlib import Path
import time
import cv2

from . import frame_extraction, quality, selection, features

# Stage names match the frontend's `stages` list and footer progress bar
# in App.tsx - keep them in sync if you rename a stage here.
STAGES = [
    ("Ingest", 8),
    ("Frame Assessment", 22),
    ("Correspondence", 55),
    ("Pose", 72),
    ("Reconstruction", 88),
    ("Coverage Analysis", 94),
    ("Confidence Model", 100),
]


def process_video(job, jobs):
    video_path = Path(job["video_path"])
    frames_dir = Path(job["frames_dir"])
    frames_dir.mkdir(parents=True, exist_ok=True)
    job["status"] = "processing"

    # --- 1. Video frame extraction ---
    job.update(stage="Ingest", progress=STAGES[0][1], message="Extracting frames from flight video")
    raw_frames, meta = frame_extraction.extract_frames(video_path, frames_dir, target_fps=2.0, max_frames=400)
    job["frames_captured"] = meta["total_frames"]
    job["duration"] = meta["duration"]

    if not raw_frames:
        job.update(status="error", message="No frames could be extracted from this video.")
        return

    # --- 2. Frame quality assessment ---
    job.update(stage="Frame Assessment", progress=STAGES[1][1], message="Scoring sharpness, exposure and contrast")
    quality_by_index = {}
    for f in raw_frames:
        img = cv2.imread(str(f["path"]))
        quality_by_index[f["index"]] = quality.assess_quality(img)
    job["avg_frame_quality"] = round(
        sum(q["score"] for q in quality_by_index.values()) / len(quality_by_index), 3
    )

    # --- 3. Intelligent frame selection ---
    job["message"] = "Selecting keyframes by quality and parallax"
    keyframes = selection.select_keyframes(raw_frames, quality_by_index)
    job["frames_selected"] = len(keyframes)

    if len(keyframes) < 2:
        job.update(status="error", message="Not enough usable frames survived quality filtering.")
        return

    # --- 4. SIFT feature extraction ---
    job.update(stage="Correspondence", progress=STAGES[2][1], message="Extracting SIFT features")
    sample = cv2.imread(str(keyframes[0]["path"]))
    h, w = sample.shape[:2]
    K = job.get("camera_intrinsics") or features.build_intrinsics(w, h)

    kp_desc = [features.extract_sift(kf["path"])[1:] for kf in keyframes]

    # --- 5/6/7. Feature matching, RANSAC verification, relative pose ---
    job["message"] = "Matching features and verifying geometry with RANSAC"
    pair_results = []
    for i in range(len(keyframes) - 1):
        kp_a, desc_a = kp_desc[i]
        kp_b, desc_b = kp_desc[i + 1]
        matches = features.match_features(desc_a, desc_b)
        pose = features.estimate_relative_pose(kp_a, kp_b, matches, K)

        pair_results.append({
            "from": keyframes[i]["index"],
            "to": keyframes[i + 1]["index"],
            "matches": len(matches),
            "inliers": pose["inliers"] if pose else 0,
            "inlier_ratio": pose["inlier_ratio"] if pose else 0.0,
            "reprojection_error": pose["reprojection_error"] if pose else None,
            "pose_recovered": pose is not None,
        })
        job["progress"] = STAGES[2][1] + int(
            (i + 1) / max(len(keyframes) - 1, 1) * (STAGES[3][1] - STAGES[2][1])
        )

    registered = [p for p in pair_results if p["pose_recovered"]]
    errs = [p["reprojection_error"] for p in registered if p["reprojection_error"] is not None]

    job.update(
        stage="Pose",
        progress=STAGES[3][1],
        pose_pairs=pair_results,
        pairs_registered=len(registered),
        pairs_total=len(pair_results),
        coverage=round(len(registered) / max(len(pair_results), 1) * 100, 1),
        reprojection_error=round(sum(errs) / len(errs), 3) if errs else None,
        message=f"Recovered relative pose for {len(registered)}/{len(pair_results)} consecutive frame pairs",
    )

    # Dense reconstruction, meshing and georeferencing are the next stages
    # to wire in - left as placeholders until the MVS/mesh engine lands.
    for stage, progress in STAGES[4:]:
        job["stage"] = stage
        job["progress"] = progress
        job["message"] = f"{stage} in progress"
        time.sleep(0.3)

    job.update(
        status="complete",
        stage="Confidence Model",
        progress=100,
        message="Feature pipeline complete. Dense reconstruction engine ready for integration.",
    )
