import cv2
import numpy as np

_sift = cv2.SIFT_create(nfeatures=2000)


def build_intrinsics(width: int, height: int, diagonal_fov_deg: float = 84.0) -> np.ndarray:
    """Approximate a camera intrinsic matrix when no calibration is supplied.

    84 degree diagonal FOV is typical for a consumer drone's wide lens. This
    is a fallback only - pass real calibration (job["camera_intrinsics"])
    when it's available, since an approximated K limits pose accuracy and
    caps how metrically correct the final scale can be without GCPs.
    """
    diag_px = np.sqrt(width ** 2 + height ** 2)
    focal = diag_px / (2 * np.tan(np.radians(diagonal_fov_deg / 2)))
    return np.array([
        [focal, 0, width / 2],
        [0, focal, height / 2],
        [0, 0, 1],
    ])


def extract_sift(image_path):
    """SIFT keypoint and descriptor extraction for one frame."""
    img = cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
    kp, desc = _sift.detectAndCompute(img, None)
    return img.shape[::-1], kp, desc


def match_features(desc_a, desc_b, ratio=0.75):
    """Descriptor matching with Lowe's ratio test to reject ambiguous matches."""
    if desc_a is None or desc_b is None or len(desc_a) < 2 or len(desc_b) < 2:
        return []
    bf = cv2.BFMatcher(cv2.NORM_L2)
    knn = bf.knnMatch(desc_a, desc_b, k=2)
    return [m for m, n in knn if m.distance < ratio * n.distance]


def estimate_relative_pose(kp_a, kp_b, matches, K):
    """RANSAC geometric verification + relative camera-pose recovery for a frame pair.

    Fits an essential matrix with RANSAC (rejects outlier matches from
    dynamic objects, repeated texture, and mismatches), then recovers the
    rotation and translation between the two views via cheirality check.
    """
    if len(matches) < 8:
        return None

    pts_a = np.float32([kp_a[m.queryIdx].pt for m in matches])
    pts_b = np.float32([kp_b[m.trainIdx].pt for m in matches])

    E, mask = cv2.findEssentialMat(pts_a, pts_b, K, method=cv2.RANSAC, prob=0.999, threshold=1.0)
    if E is None or mask is None:
        return None

    inliers = int(mask.sum())
    if inliers < 8:
        return None

    _, R, t, _ = cv2.recoverPose(E, pts_a, pts_b, K, mask=mask)

    # Symmetric epipolar transfer error over inliers, as a reprojection proxy.
    F = np.linalg.inv(K).T @ E @ np.linalg.inv(K)
    errs = []
    for pa, pb, keep in zip(pts_a, pts_b, mask.ravel()):
        if not keep:
            continue
        a = np.array([pa[0], pa[1], 1.0])
        b = np.array([pb[0], pb[1], 1.0])
        line = F @ a
        denom = np.hypot(line[0], line[1]) + 1e-9
        errs.append(abs(b @ line) / denom)

    return {
        "matches": len(matches),
        "inliers": inliers,
        "inlier_ratio": round(inliers / len(matches), 3),
        "reprojection_error": round(float(np.mean(errs)), 3) if errs else None,
        "rotation": R.tolist(),
        "translation": t.flatten().tolist(),
    }
