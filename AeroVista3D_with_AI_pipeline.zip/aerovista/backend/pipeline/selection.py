import cv2
import numpy as np


def select_keyframes(frames, quality_by_index, min_quality=0.35, min_parallax=6.0, max_gap=6):
    """Pick a temporally-ordered subset of frames for the SfM stage.

    A frame is kept when it clears the quality floor AND has moved enough
    from the last kept frame to give the pose solver real parallax - two
    near-duplicate frames add compute without adding information. max_gap
    forces a keyframe even through a static or quality-poor stretch so a
    blurry or low-texture patch doesn't create a hole in the pose chain.

    min_parallax is median optical-flow magnitude in pixels at the 320x180
    working scale used here - it's altitude- and speed-dependent, so treat
    the default as a starting point and recalibrate against real flight
    footage rather than trusting it blind.
    """
    selected = []
    last_small = None
    gap = 0

    for f in frames:
        q = quality_by_index[f["index"]]["score"]
        img = cv2.imread(str(f["path"]), cv2.IMREAD_GRAYSCALE)
        img_small = cv2.resize(img, (320, 180))

        keep = False
        parallax = None
        if last_small is None:
            keep = True
        else:
            flow = cv2.calcOpticalFlowFarneback(
                last_small, img_small, None, 0.5, 2, 15, 3, 5, 1.2, 0
            )
            parallax = float(np.median(np.linalg.norm(flow, axis=2)))
            if (q >= min_quality and parallax >= min_parallax) or gap >= max_gap:
                keep = True

        if keep:
            selected.append({**f, "quality": q, "parallax": parallax})
            last_small = img_small
            gap = 0
        else:
            gap += 1

    return selected
