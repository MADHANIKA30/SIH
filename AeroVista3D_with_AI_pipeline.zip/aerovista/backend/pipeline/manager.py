from pathlib import Path
from threading import Thread
from uuid import uuid4
from .processor import process_video

class JobManager:
    def __init__(self):
        self.jobs = {}

    def new_id(self):
        return uuid4().hex[:12]

    def create_job(self, path: Path, original_name: str):
        job_id = self.new_id()
        job = {
            "id": job_id,
            "filename": original_name,
            "video_path": str(path),
            "status": "queued",
            "stage": "Ingest",
            "progress": 0,
            "frames_captured": 0,
            "frames_selected": 0,
            "coverage": 0,
            "reprojection_error": None,
            "duration": None,
            "frames_dir": str(path.parent / job_id),
            "model_path": None,
            "message": "Flight uploaded. Processing queued."
        }
        self.jobs[job_id] = job
        Thread(target=self._run, args=(job_id,), daemon=True).start()
        return job

    def _run(self, job_id):
        process_video(self.jobs[job_id], self.jobs)

    def get(self, job_id):
        return self.jobs.get(job_id)
