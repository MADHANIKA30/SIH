import cv2
import numpy as np


def assess_quality(frame_bgr: np.ndarray) -> dict:
    """Score a frame on sharpness, exposure and contrast.

    Sharpness: variance of the Laplacian. Low values mean motion blur or
    compression softening, the dominant artifact in single-pass drone video.
    Exposure: mean brightness. Flags over/under-exposed frames caused by
    changing illumination and shadows during the flight.
    Contrast: standard deviation of intensity. Flags flat, low-texture
    frames (sky, plain rooftops) that starve SIFT of usable keypoints.
    """
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    sharpness = cv2.Laplacian(gray, cv2.CV_64F).var()
    brightness = float(gray.mean())
    contrast = float(gray.std())

    sharpness_score = min(sharpness / 150.0, 1.0)
    exposure_score = 1.0 - min(abs(brightness - 128.0) / 128.0, 1.0)
    contrast_score = min(contrast / 60.0, 1.0)

    overall = 0.5 * sharpness_score + 0.25 * exposure_score + 0.25 * contrast_score
    return {
        "sharpness": round(sharpness, 1),
        "brightness": round(brightness, 1),
        "contrast": round(contrast, 1),
        "score": round(overall, 3),
    }
