from pathlib import Path
import cv2


def extract_frames(video_path: Path, out_dir: Path, target_fps: float = 2.0, max_frames: int = 400):
    """Sample frames from the flight video at a fixed rate.

    Sampling at target_fps (rather than decoding every frame) keeps quality
    assessment and SIFT/matching tractable on a multi-minute single-pass
    flight, and roughly matches the frame spacing an SfM front-end expects.
    max_frames caps runaway processing on very long flights.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError("Unable to open video")

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration = total / fps if total else 0.0
    sample_every = max(int(round(fps / target_fps)), 1)

    frames = []
    idx = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % sample_every == 0:
            name = f"raw_{len(frames):04d}.jpg"
            path = out_dir / name
            cv2.imwrite(str(path), frame)
            frames.append({"index": len(frames), "source_frame": idx, "path": path})
            if len(frames) >= max_frames:
                break
        idx += 1

    cap.release()
    return frames, {"fps": fps, "total_frames": total, "duration": round(duration, 2)}
