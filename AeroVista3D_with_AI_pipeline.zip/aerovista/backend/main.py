from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pathlib import Path
from pipeline.manager import JobManager

BASE = Path(__file__).resolve().parent
UPLOADS = BASE / "uploads"
UPLOADS.mkdir(exist_ok=True)

app = FastAPI(title="AeroVista 3D API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

manager = JobManager()

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "AeroVista 3D"}

@app.post("/api/flights")
async def upload_flight(video: UploadFile = File(...)):
    allowed = {".mp4", ".mov", ".avi", ".mkv", ".webm"}
    suffix = Path(video.filename or "").suffix.lower()
    if suffix not in allowed:
        raise HTTPException(400, "Unsupported video format")

    target = UPLOADS / f"{manager.new_id()}{suffix}"
    with target.open("wb") as f:
        while chunk := await video.read(1024 * 1024):
            f.write(chunk)

    job = manager.create_job(target, video.filename or target.name)
    return job

@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    job = manager.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job

@app.get("/api/jobs/{job_id}/frames/{frame_name}")
def get_frame(job_id: str, frame_name: str):
    job = manager.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    path = Path(job["frames_dir"]) / frame_name
    if not path.exists():
        raise HTTPException(404, "Frame not found")
    return FileResponse(path)

@app.get("/api/jobs/{job_id}/model")
def get_model(job_id: str):
    job = manager.get(job_id)
    if not job or not job.get("model_path"):
        raise HTTPException(404, "3D model not available")
    return FileResponse(job["model_path"], media_type="model/gltf-binary")
