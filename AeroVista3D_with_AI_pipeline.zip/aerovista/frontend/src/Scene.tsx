import { useEffect, useRef } from "react";
import * as THREE from "three";

export function Scene({selected,onSelect}:{selected:string,onSelect:(s:string)=>void}){
  const ref=useRef<HTMLDivElement>(null);
  useEffect(()=>{
    if(!ref.current) return;
    const el=ref.current;
    const scene=new THREE.Scene(); scene.background=new THREE.Color(0xf0f3f5);
    const camera=new THREE.PerspectiveCamera(38,el.clientWidth/el.clientHeight,.1,1000);
    camera.position.set(15,14,18); camera.lookAt(0,0,0);
    const renderer=new THREE.WebGLRenderer({antialias:true}); renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.setSize(el.clientWidth,el.clientHeight); el.appendChild(renderer.domElement);
    scene.add(new THREE.HemisphereLight(0xffffff,0xb7c0c8,2.4));
    const dir=new THREE.DirectionalLight(0xffffff,2); dir.position.set(8,20,10); scene.add(dir);

    const ground=new THREE.Mesh(new THREE.PlaneGeometry(28,22),new THREE.MeshStandardMaterial({color:0xdfe4e6,roughness:1})); ground.rotation.x=-Math.PI/2; scene.add(ground);
    const roadMat=new THREE.MeshStandardMaterial({color:0xc6ccd1});
    const road=new THREE.Mesh(new THREE.BoxGeometry(30,.04,2.4),roadMat); road.position.y=.03; scene.add(road);
    const road2=new THREE.Mesh(new THREE.BoxGeometry(2.2,.045,22),roadMat); road2.position.set(4,.04,0); scene.add(road2);

    const mats=[
      new THREE.MeshStandardMaterial({color:0xd2d7da}),
      new THREE.MeshStandardMaterial({color:0xc4cdd3}),
      new THREE.MeshStandardMaterial({color:0xd9dddf})
    ];
    const buildings=[[-5,1.2,-3,4,2.4,5],[-.5,1.7,-4,4.5,3.4,3.5],[5,1.1,-2.8,3.4,2.2,4],[ -3,1,-.2,3.5,2,3],[1.8,1.4,3,4.8,2.8,3.4],[6.5,1,4,2.4,2,3]];
    buildings.forEach((b,i)=>{const [x,y,z,w,h,d]=b;const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mats[i%3]);m.position.set(x,y,z);m.userData.region=`R-${String(42+i*9).padStart(3,"0")}`;scene.add(m)});
    const lineMat=new THREE.LineBasicMaterial({color:0x2d73b9});
    const pts=[new THREE.Vector3(-10,.5,8),new THREE.Vector3(-5,.8,5),new THREE.Vector3(0,1,2),new THREE.Vector3(5,1,-1),new THREE.Vector3(10,1,-4)];
    scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),lineMat));
    pts.forEach(p=>{const q=new THREE.Mesh(new THREE.SphereGeometry(.12,12,12),new THREE.MeshBasicMaterial({color:0x2d73b9}));q.position.copy(p);scene.add(q)});
    const rayMat=new THREE.LineBasicMaterial({color:0x6d9fbc,transparent:true,opacity:.7});
    const ray=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0,1,2),new THREE.Vector3(5,0,2)]),rayMat);scene.add(ray);

    const onResize=()=>{camera.aspect=el.clientWidth/el.clientHeight;camera.updateProjectionMatrix();renderer.setSize(el.clientWidth,el.clientHeight)};window.addEventListener("resize",onResize);
    const raycaster=new THREE.Raycaster(), mouse=new THREE.Vector2();
    const click=(e:MouseEvent)=>{const r=el.getBoundingClientRect();mouse.x=((e.clientX-r.left)/r.width)*2-1;mouse.y=-((e.clientY-r.top)/r.height)*2+1;raycaster.setFromCamera(mouse,camera);const hits=raycaster.intersectObjects(scene.children);const h=hits.find(x=>x.object.userData.region);if(h) onSelect(h.object.userData.region)};
    el.addEventListener("click",click);
    let id=0; const animate=()=>{id=requestAnimationFrame(animate);renderer.render(scene,camera)};animate();
    return()=>{cancelAnimationFrame(id);el.removeEventListener("click",click);window.removeEventListener("resize",onResize);renderer.dispose();el.removeChild(renderer.domElement)};
  },[onSelect]);
  return <div className="scene" ref={ref}/>;
}
