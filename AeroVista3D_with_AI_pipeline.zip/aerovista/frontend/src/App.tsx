import { useMemo, useRef, useState } from "react";
import { Activity, Box, ChevronDown, CircleHelp, FileText, FolderOpen, Layers3, Map, Maximize2, Minus, Plus, Settings, Upload, Video, Waypoints } from "lucide-react";
import { Scene } from "./Scene";

const API = "http://localhost:8000";

type Job = {
  id:string; filename:string; status:string; stage:string; progress:number;
  frames_captured:number; frames_selected:number; coverage:number;
  reprojection_error:number|null; duration:number|null; message:string;
};

const demo: Job = {
  id:"demo", filename:"Flight 07", status:"complete", stage:"Confidence Model", progress:100,
  frames_captured:1284, frames_selected:312, coverage:87.4, reprojection_error:.42,
  duration:888, message:"Processing complete"
};

export default function App(){
  const input = useRef<HTMLInputElement>(null);
  const [job,setJob] = useState<Job>(demo);
  const [selected,setSelected] = useState("R-042");
  const [tab,setTab] = useState("Overview");

  async function upload(file: File){
    const form = new FormData(); form.append("video",file);
    const res = await fetch(`${API}/api/flights`,{method:"POST",body:form});
    if(!res.ok) return;
    const initial:Job = await res.json(); setJob(initial);
    const timer = window.setInterval(async()=>{
      const r = await fetch(`${API}/api/jobs/${initial.id}`);
      if(!r.ok) return;
      const next:Job = await r.json(); setJob(next);
      if(next.status==="complete" || next.status==="error") window.clearInterval(timer);
    },800);
  }

  const metrics = useMemo(()=>[
    ["Frames Captured", job.frames_captured.toLocaleString()],
    ["Frames Selected", job.frames_selected.toLocaleString()],
    ["Observed Coverage", `${job.coverage || 0}%`],
    ["Reprojection Error", job.reprojection_error ? `${job.reprojection_error} px` : "—"],
    ["Flight Duration", job.duration ? `${Math.floor(job.duration/60)}:${String(Math.round(job.duration%60)).padStart(2,"0")}` : "—"],
  ],[job]);

  const stages=["Ingest","Frame Assessment","Correspondence","Pose","Reconstruction","Coverage Analysis","Confidence Model"];

  return <div className="app">
    <header className="topbar">
      <div className="brand"><span className="mark">AV</span><b>AeroVista 3D</b></div>
      <div className="project"><small>PROJECT</small><b>Industrial Site Survey</b><ChevronDown size={13}/></div>
      <div className="project flight"><small>FLIGHT</small><b>{job.filename || "Flight 07"}</b></div>
      <div className="topStatus"><span className="statusDot"/> {job.status==="complete"?"Processing complete":job.stage}</div>
      <button className="icon"><CircleHelp size={16}/></button><button className="icon"><Settings size={16}/></button>
    </header>

    <div className="subbar">
      <span>Projects</span><span>/</span><span>Industrial Site Survey</span><span>/</span><b>Flight 07</b>
      <div className="actions"><button onClick={()=>input.current?.click()}><Upload size={14}/> Upload Flight</button><button><FileText size={14}/> Export</button><button><Box size={14}/> View 3D Model</button></div>
      <input ref={input} hidden type="file" accept="video/*" onChange={e=>e.target.files?.[0] && upload(e.target.files[0])}/>
    </div>

    <div className="workspace">
      <aside className="sidebar">
        <div className="label">WORKSPACE</div>
        {[
          ["Overview",Activity],["Flight Data",Video],["Frame Analysis",Layers3],["Reconstruction",Waypoints],["Coverage",Map],["3D Viewer",Box],["Reports",FileText]
        ].map(([name,Icon]:any)=><button key={name} className={`nav ${tab===name?"active":""}`} onClick={()=>setTab(name)}><Icon size={15}/>{name}</button>)}
        <div className="rule"/>
        <div className="label">CURRENT SURVEY</div>
        <div className="site"><b>Industrial Site</b><p>Continuous drone flight workspace</p><div><span>Area</span><b>4.8 ha</b></div><div><span>Altitude</span><b>42 m</b></div><div><span>GSD</span><b>1.8 cm</b></div><div><span>Model</span><b>Ready</b></div></div>
      </aside>

      <main className="main">
        <div className="heading"><div><small>FLIGHT WORKSPACE</small><h1>{tab}</h1></div><div className="flightMeta">Single-pass flight · 42 m AGL · 1.8 cm GSD</div></div>
        <div className="metrics">{metrics.map(([a,b])=><div className="metric" key={a}><span>{a}</span><b>{b}</b></div>)}</div>
        <section className="viewer">
          <div className="viewportTools"><button>Orbit</button><button>Pan</button><button>Measure</button><button>Layers</button><button>Coverage</button></div>
          <Scene selected={selected} onSelect={setSelected}/>
          <div className="viewLabel"><b>3D SURVEY VIEW</b><span>Perspective · North-up</span></div>
          <div className="legend"><i className="observed"/>Observed <i className="interpolated"/>Interpolated <i className="inferred"/>Inferred <i className="missing"/>Missing</div>
          <div className="zoom"><button><Plus size={15}/></button><button><Minus size={15}/></button><button><Maximize2 size={13}/></button></div>
        </section>
      </main>

      <aside className="inspector">
        <div className="panelTitle">INSPECTION <span>×</span></div>
        <div className="inspectBody">
          <div className="selection"><div className="tag">OBSERVED GEOMETRY</div><h3>Coverage Region {selected}</h3><small>North facade · Building B-02</small>
            <Property a="Confidence" b="96.8%"/><Property a="Source frames" b="F-118, F-121, F-124"/><Property a="Observation angle" b="34°"/><Property a="Geometry source" b="Measured"/><Property a="Reprojection error" b="0.38 px"/>
            <p>Strong multi-view correspondence. Region is directly supported by captured imagery.</p>
          </div>
          <div className="label inner">MODEL STATUS</div>
          <Property a="Point cloud" b="2.84 M points"/><Property a="Mesh faces" b="1.26 M"/><Property a="Observed coverage" b="87.4%"/><Property a="Inferred area" b="8.1%"/><Property a="Missing area" b="4.5%"/>
        </div>
      </aside>
    </div>

    <footer className="bottom">
      <div className="pipeline">{stages.map((s,i)=><div className={`stage ${job.progress>=([8,22,38,52,72,88,100][i])?"done":""}`} key={s}><b>{job.progress>=([8,22,38,52,72,88,100][i])?"✓":i+1}</b>{s}{i<stages.length-1&&<em/>}</div>)}</div>
      <div className="timeline"><div><b>Flight 07</b><small>{job.duration?`${Math.floor(job.duration/60)}:${String(Math.round(job.duration%60)).padStart(2,"0")}`:"14:08–14:23"} · {job.frames_captured.toLocaleString()} frames</small></div><div className="film">{Array.from({length:15},(_,i)=><button className={i%4===2?"discard":"keep"} key={i}><span>F-{String(112+i*9).padStart(3,"0")}</span></button>)}<i className="playhead"/></div><div className="retained"><b>{job.frames_selected.toLocaleString()} / {job.frames_captured.toLocaleString()}</b><small>frames retained</small></div></div>
    </footer>
  </div>
}
function Property({a,b}:{a:string,b:string}){return <div className="property"><span>{a}</span><b>{b}</b></div>}
